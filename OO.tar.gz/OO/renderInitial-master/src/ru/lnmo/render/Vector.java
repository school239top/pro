package ru.lnmo.render;

import org.w3c.dom.ls.LSOutput;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;



public class Vector {
    static double x1,y1;
    static double x2,y2;


    public Vector(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public static class constr {
        double X;
        double Y;
        double Z;

        public constr(double X, double Y, double Z) {
            this.X= X;
            this.Y = Y;
            this.Z = Z;
        }
    }


   public static ArrayList<constr> listcoor = new ArrayList<>();
   public static ArrayList<TangleOBJ>  listtrian= new ArrayList<>();


    public static void parseCoord()  {
        Scanner s = null;
        try {
            s = new Scanner(new File("/home/student/Desktop","uaz.obj"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        listcoor.add(new constr(0,0,0));
        for(int i = 0; i<546;i++){
            String next = s.nextLine();
            if(next.startsWith("v")){
                double x;
                double y;
                double z;
                String a[] = next.split(" ");
                x = Double.parseDouble(a[1]);
                y = Double.parseDouble(a[2]);
                z = Double.parseDouble(a[3]);
                listcoor.add(new constr(x,y,z));

            }
        }
    }

    public static void parseTriangle ()  {
        Scanner s = null;
        try {
            s = new Scanner(new File("/home/student/Desktop","uaz.obj"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        while(s.hasNextLine()){
            String next = s.nextLine();
            if(next.startsWith("f ")){
                double x1=0;
                double y1=0;
                double x2=0;
                double y2=0;
                double x3=0;
                double y3=0;
                String ss[] = next.split(" ");
                for (int j = 1; j <4 ; j++) {
                    String sd[] = ss[j].split("/");
                    constr xa = listcoor.get(Integer.parseInt(sd[0]));
                    if (j==1){
                        x1=xa.X;
                        y1=xa.Y;
                    } else if (j==2){
                        x2=xa.X;
                        y2=xa.Y;
                    } else {
                        x3=xa.X;
                        y3=xa.Y;
                    }
                }

                listtrian.add(new TangleOBJ(x1,y1,x2,y2,x3,y3));
                System.out.println(x1+" "+ y1+" "+ x2+" "+ y2+" "+ x3+" "+ y3);
            }
        }
        System.out.println();
    }
    public static void line(BufferedImage img,double x1,double y1,double x2, double y2){
        if(x1>x2){
            for (double i = x2; i < x1; i++) {
                double y = (i-x1)/(x2-x1) * (y2-y1) + y1;
                System.out.println(x2+" "+y2);
                img.setRGB((int)i, (int)y, new Color(118, 0, 0, 169).getRGB() );
            }
        }if(x1<x2){
            for (double i = x1; i < x2; i++) {
                double y = (i-x1)/(x2-x1) * (y2-y1) + y1;
                img.setRGB((int)i, (int)y, new Color(118, 0, 0, 169).getRGB() );
            }
        }
        if(x1 == x2){
            if( y1 < y2){
                for (double i = y1; i <=y2 ; i++) {
                    img.setRGB((int)x1, (int)i, new Color(118, 0, 0, 169).getRGB() );
                }
            }else{
                for (double i = y2; i <=y1 ; i++) {
                    img.setRGB((int) x1, (int) i, new Color(118, 0, 0, 169).getRGB());
                }
            }
        }

    }


    public  static void tangle(BufferedImage img, double x1, double y1, double x2, double y2, double x3, double y3){
        for (int x = 0; x <=Main.w ; x++) {
            for (int y = 0; y < Main.h; y++) {
                double t = Math.signum((x1 - x)*(y2-y1) - (x2-x1)*(y1-y));
                double v = Math.signum((x2 - x)*(y3-y2) - (x3-x2)*(y2-y));
                double r = Math.signum((x3 - x)*(y1-y3) - (x1-x3)*(y3-y));
                if(t == v && v == r && r==t){
                    img.setRGB((int) x, (int) y, new Color(118, 0, 0, 169).getRGB());
                }
            }

        }
    }

}