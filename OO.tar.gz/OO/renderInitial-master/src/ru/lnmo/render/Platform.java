package ru.lnmo.render;

import org.jbox2d.callbacks.*;
import org.jbox2d.collision.AABB;
import org.jbox2d.collision.Manifold;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.collision.shapes.EdgeShape;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.collision.shapes.Shape;
import org.jbox2d.common.*;
import org.jbox2d.dynamics.*;
import org.jbox2d.dynamics.contacts.Contact;
import org.jbox2d.pooling.IWorldPool;
import org.jbox2d.testbed.framework.TestbedSettings;
import org.jbox2d.testbed.framework.TestbedTest;


public class Platform extends TestbedTest{
    private static final long BODY_TAG = 12;
    Body m_body;
    int health = 100;
    static  boolean checker = false;

    final float k_restitution = 1.0f;
    CircleShape m_circle;

    @Override
    public void initTest(boolean deserialized) {
        setTitle("QQQQQQQ");
        {  //creat_polygon
            PolygonShape sd = new PolygonShape();
            CircleShape ed = new CircleShape();
            ed.setRadius(50);
            sd.setAsBox(50.0f, 10.0f);
        }
        {
            getWorld().setContactListener(new ContactListener() {
                @Override
                public void beginContact(Contact contact) {
                    System.out.println("beging" + contact.m_fixtureA.m_userData + "  " + contact.m_fixtureB.m_userData);

                }

                @Override
                public void endContact(Contact contact) {
                    System.out.println("end" + contact.m_fixtureA.m_userData + "  " + contact.m_fixtureB.m_userData);

                }

                @Override
                public void preSolve(Contact contact, Manifold oldManifold) {

                }

                @Override
                public void postSolve(Contact contact, ContactImpulse impulse) {

                }
            });

        }//contactlistener













        getWorld().setGravity(new Vec2(0.0f, 0.0f));

            /*Body ground;
        {
                BodyDef bd = new BodyDef();
                bd.position.set(0.0f, 20.0f);
                ground = getWorld().createBody(bd);

                EdgeShape shape = new EdgeShape();

                FixtureDef sd = new FixtureDef();
                sd.shape = shape;
                sd.density = 0.0f;
                sd.restitution = k_restitution;
        }*/



     /*   {  //Platforms

                FixtureDef fd = new FixtureDef();
                PolygonShape sd = new PolygonShape();
                sd.setAsBox(30.0f, 0.125f);
                fd.shape = sd;

                BodyDef bd = new BodyDef();
                bd.position = new Vec2(0.0f, 0.01f);
                getWorld().createBody(bd).createFixture(fd);


        }*/
        Body ground;
        {
            BodyDef bd = new BodyDef();
            bd.position.set(0.0f, 20.0f);
            ground = getWorld().createBody(bd);

            EdgeShape shape = new EdgeShape();

            FixtureDef sd = new FixtureDef();
            sd.shape = shape;
            sd.density = 0.0f;
            sd.userData = "WALL";
            sd.restitution = k_restitution;


            // Left vertical
            shape.set(new Vec2(-80.0f, -80.0f), new Vec2(-80.0f, 80.0f));
            ground.createFixture(sd);

            // Right vertical
            shape.set(new Vec2(80.0f, -80.0f), new Vec2(80.0f, 80.0f));
            ground.createFixture(sd);

            // Top horizontal
            shape.set(new Vec2(-80.0f, 80.0f), new Vec2(80.0f, 80.0f));
            ground.createFixture(sd);

            // Bottom horizontal
            shape.set(new Vec2(-80.0f, -80.0f), new Vec2(80.0f, -80.0f));
            ground.createFixture(sd);

        }

        Body Zone;
        {
            BodyDef edd = new BodyDef();
            edd.position.set(0.0f, 20.0f);
            Zone = getWorld().createBody(edd);

            CircleShape edge = new CircleShape();
            edge.setRadius(200);
            FixtureDef ed = new FixtureDef();
            ed.shape = edge;
            ed.density = 0.0f;
            ed.userData = "ZONE";
            ed.restitution = k_restitution;
            Zone.createFixture(ed);
            
        }
     /*   {// creat dino
            FixtureDef fd = new FixtureDef();
            PolygonShape sd = new PolygonShape();
            sd.setAsBox(1.0f, 4.0f);
            fd.shape = sd;
            fd.density = 75.0f;

            BodyDef bd = new BodyDef();
            bd.type = BodyType.DYNAMIC;
            bd.position = new Vec2(0.0f, 21.0f);
            getWorld().createBody(bd).createFixture(fd);

        }*/


        {
            Transform xf1 = new Transform();
            xf1.q.set(0.3524f * MathUtils.PI);
            Rot.mulToOutUnsafe(xf1.q, new Vec2(1.0f, 0.0f), xf1.p);

            Vec2 vertices[] = new Vec2[5];
            vertices[0] = Transform.mul(xf1, new Vec2(-2.0f, 0.0f));
            vertices[1] = Transform.mul(xf1, new Vec2(2.0f, 0.0f));
            vertices[2] = Transform.mul(xf1, new Vec2(0.0f, 2.0f));
            vertices[3] = Transform.mul(xf1, new Vec2(0.0f,-2.0f));
            vertices[4] = Transform.mul(xf1, new Vec2(-2.0f,-2.0f));

            PolygonShape poly1 = new PolygonShape();
            poly1.set(vertices, 5);

            FixtureDef sd1 = new FixtureDef();
            sd1.shape = poly1;
            sd1.userData = "Player";
            sd1.density = 10.0f;
            sd1.restitution = k_restitution;




            BodyDef bd = new BodyDef();
            bd.type = BodyType.DYNAMIC;
            bd.angularDamping = 5.0f;
            
            bd.linearDamping = 0.1f;

            bd.position.set(0.0f, 2.0f);
            bd.angle = MathUtils.PI;
            bd.allowSleep = false;
            m_body = getWorld().createBody(bd);
            m_body.createFixture(sd1);









        }





    }



    public void step(TestbedSettings settings) {
        super.step(settings);

        addTextLine("Use 'wasd' to move, 'e' and 's' drift.");
        if (getModel().getKeys()['w']) {
            Vec2 f = m_body.getWorldVector(new Vec2(0.0f, -2000.0f));
            Vec2 p = m_body.getWorldPoint(m_body.getLocalCenter().add(new Vec2(0.0f, 20.0f)));
            m_body.applyForce(f, p);
        } else if (getModel().getKeys()['q']) {
            Vec2 f = m_body.getWorldVector(new Vec2(0.0f, -1000.0f));
            Vec2 p = m_body.getWorldPoint(m_body.getLocalCenter().add(new Vec2(-.600f, 0f)));
            m_body.applyForce(f, p);
        } else if (getModel().getKeys()['e']) {
            Vec2 f = m_body.getWorldVector(new Vec2(0.0f, -1000.0f));
            Vec2 p = m_body.getWorldPoint(m_body.getLocalCenter().add(new Vec2(.600f, 0f)));
            m_body.applyForce(f, p);
        } else if (getModel().getKeys()['s']) {
            Vec2 f = m_body.getWorldVector(new Vec2(0.0f, 2000.0f));
            Vec2 p = m_body.getWorldCenter();
            m_body.applyForce(f, p);
        }
        if (getModel().getKeys()['a']) {
            m_body.applyTorque(3500.0f);
        }

        if (getModel().getKeys()['d']) {
            m_body.applyTorque(-3500.0f);
        }

        PolyShapesCallback callback = new PolyShapesCallback(getWorld().getPool());
        callback.m_circle.m_radius = 80.0f;
        callback.m_circle.m_p.set(-1.0f, 20.0f);
        callback.m_transform.setIdentity();
        callback.debugDraw = getDebugDraw();

        AABB aabb = new AABB();
        callback.m_circle.computeAABB(aabb, callback.m_transform, 0);

        getWorld().queryAABB(callback, aabb);

        Color3f color = new Color3f(0.4f, 0.7f, 0.8f);
        getDebugDraw().drawCircle(callback.m_circle.m_p, callback.m_circle.m_radius, color);

    }

    class PolyShapesCallback implements QueryCallback {
        int e_maxCount = 30;
        CircleShape m_circle = new CircleShape();
        Transform m_transform = new Transform();
        DebugDraw debugDraw;
        int m_count;
        IWorldPool p;

        public PolyShapesCallback(IWorldPool argWorld) {
            m_count = 0;
            p = argWorld;
        }

        void DrawFixture(Fixture fixture) {//0.95 0.95 0.6
            Color3f color = new Color3f(0.95f, 0.6f, 0.6f);
            final Transform xf = fixture.getBody().getTransform();

            //System.out.println(checker);
            switch (fixture.getType()) {
                case CIRCLE: {
                    CircleShape circle = (CircleShape) fixture.getShape();

                    Vec2 center = Transform.mul(xf, circle.m_p);
                    float radius = circle.m_radius;
                    debugDraw.drawCircle(center, radius, color);
                }
                break;

                case POLYGON: {
                    PolygonShape poly = (PolygonShape) fixture.getShape();
                    int vertexCount = poly.m_count;
                    assert (vertexCount <= Settings.maxPolygonVertices);
                    Vec2 vertices[] = new Vec2[Settings.maxPolygonVertices];

                    for (int i = 0; i < vertexCount; ++i) {
                        vertices[i] = Transform.mul(xf, poly.m_vertices[i]);
                    }

                    debugDraw.drawPolygon(vertices, vertexCount, color);
                }


                break;
                default:
                    break;
            }
        }

        public boolean reportFixture(Fixture fixture) {
            if (m_count == e_maxCount) {
                return false;
            }

            Body body = fixture.getBody();
            Shape shape = fixture.getShape();

            boolean overlap = p.getCollision().testOverlap(shape, 0, m_circle, 0, body.getTransform(),
                    m_transform);

            if (overlap) {
                DrawFixture(fixture);
                ++m_count;
            }

            return true;
        }
    }








    @Override
    public boolean isSaveLoadEnabled() {
        return true;
    }

    @Override
    public Long getTag(Body body) {
        if (body == m_body) {
            return BODY_TAG;
        }
        return super.getTag(body);
    }

    @Override
    public void processBody(Body body, Long tag) {
        if (tag == BODY_TAG) {
            m_body = body;
        }
        super.processBody(body, tag);
    }

    @Override
    public String getTestName() {
        return "QQQQQQQQQQQQ";
    }



}
