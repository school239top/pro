package ru.lnmo.render;

import org.jbox2d.testbed.framework.TestbedMain;
import org.jbox2d.testbed.framework.TestbedTest;

public class Q {
    public static void main(String[] args) {
        TestbedMain.main(args);
    }
}
